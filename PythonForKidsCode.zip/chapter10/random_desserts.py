import random
desserts = [ 'ice cream', 'pancakes', 'brownies', 'cookies', 'candy' ]
print(random.choice(desserts))

random.shuffle(desserts)
print(desserts)
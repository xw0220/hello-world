def testfunc(myname):
    print('hello %s' % myname)
    
testfunc('Mary')
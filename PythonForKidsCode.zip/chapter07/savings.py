def savings(pocket_money, paper_route, spending):
    return pocket_money + paper_route – spending
    
print(savings(10, 10, 5))
def testfunc(fname, lname):
    print('Hello %s %s' % (fname, lname))

testfunc('Mary', 'Smith')

firstname = 'Joe'
lastname = 'Robertson'
testfunc(firstname, lastname)
class Giraffe:
    def __init__(self, spots):
        self.giraffe_spots = spots

ozwald = Giraffes(100)
gertrude = Giraffes(150)
print(ozwald.giraffe_spots)
print(gertrude.giraffe_spots)
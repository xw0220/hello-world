import turtle
t = turtle.Pen()
t.forward(50)
t.left(104.47751218592992)
t.forward(100)
t.left(151.04497562814015)
t.forward(100)
t.left(104.47751218592992)
roofs = 3
ninjas_per_roof = 25
tunnels = 2
samurai_per_tunnel = 40
print((roofs * ninjas_per_roof) + (tunnels * samurai_per_tunnel))
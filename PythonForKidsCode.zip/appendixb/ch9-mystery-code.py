a = abs(10) + abs(-10)
print(a)

b = abs(-10) + -10
print(b)

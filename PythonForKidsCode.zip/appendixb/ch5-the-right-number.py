amount = 800
if (amount >= 100 and amount <= 500) or (amount >= 1000 and amount <= 5000):
    print('amount is between 100 & 500 or between 1000 & 5000')
    
amount = 400
if (amount >= 100 and amount <= 500) or (amount >= 1000 and amount <= 5000):
    print('amount is between 100 & 500 or between 1000 & 5000')

amount = 3000
if (amount >= 100 and amount <= 500) or (amount >= 1000 and amount <= 5000):
    print('amount is between 100 & 500 or between 1000 & 5000')

ninjas = 5
if ninjas < 10:
    print("I can fight those ninjas!")
elif ninjas < 30:
    print("It'll be a struggle, but I can take 'em")
elif ninjas < 50:
    print("That's too many")
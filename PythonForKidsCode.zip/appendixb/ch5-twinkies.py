twinkies = 600
if twinkies < 100 or twinkies > 500:
    print('Too few or too many')
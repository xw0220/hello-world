for x in range(0, 20):
    print('hello %s' % x)
    if x < 9:
        break
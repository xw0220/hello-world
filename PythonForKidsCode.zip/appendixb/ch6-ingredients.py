ingredients = [ 'snails', 'leeches', 'gorilla belly-button lint', 'caterpillar eyebrows', 'centipede toes' ]
x = 1
for i in ingredients:
    print('%s %s' % (x, i)) 
    x = x + 1
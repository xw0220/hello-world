for x in range(2, 16, 2):
    print(x)
games = [ 'Pokemon', 'Lego Mindstorms', 'Mountain Biking' ]
foods = [ 'Pancakes', 'Chocolate', 'Apples' ]
favorites = games + foods
print(favorites)
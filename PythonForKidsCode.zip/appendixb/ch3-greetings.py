first_name = 'Brando'
last_name = 'Ickett'
print('Hi there, %s %s' % (first_name, last_name))
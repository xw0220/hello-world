import turtle
t = turtle.Pen()

for x in range(1,5):
    t.forward(50)
    t.left(90)
import turtle
t = turtle.Pen()

for x in range(1,20):
    t.forward(100)
    t.left(95)
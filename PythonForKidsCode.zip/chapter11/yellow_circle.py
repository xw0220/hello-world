import turtle
t = turtle.Pen()

t.color(1,1,0) 
t.begin_fill() 
t.circle(50) 
t.end_fill()
found_coins = 20
magic_coins = 10
stolen_coins = 3
print(found_coins + magic_coins * 365 - stolen_coins * 52)
stolen_coins = 2
print(found_coins + magic_coins * 365 - stolen_coins * 52)
magic_coins = 13
print(found_coins + magic_coins * 365 - stolen_coins * 52)
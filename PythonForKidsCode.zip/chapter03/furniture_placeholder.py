furniture = '%s: a device for finding furniture in the dark'
bodypart1 = 'Knee'
bodypart2 = 'Shin'
print(furniture % bodypart1)
print(furniture % bodypart2)
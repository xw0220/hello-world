favorite_sports = { 'Ralph Williams' : 'Football', 'Michael Tippett' : 'Basketball', 'Edward Elgar' : 'Baseball', 'Rebecca Clarke' : 'Netball', 'Ethel Smyth' : 'Badminton', 'Frank Bridge' : 'Rugby' }
print(favorite_sports['Rebecca Clarke'])
del favorite_sports['Ethel Smyth']
print(favorite_sports)
favorite_sports['Ralph Williams'] = 'Ice Hockey'
print(favorite_sports)
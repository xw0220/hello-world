numbers = [ 1, 2, 3, 4 ]
strings = [ 'I', 'kicked', 'my', 'toe', 'and', 'it', 'is', 'sore' ]
mylist = [ numbers, strings ]
print(mylist)
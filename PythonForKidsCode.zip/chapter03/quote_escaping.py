single_quote_str = 'He said, "Aren\'t can\'t shouldn\'t wouldn\'t."'
print(single_quote_string)
double_quote_str = "He said, \"Aren't can't shouldn't wouldn't.\""
print(double_quote_string)
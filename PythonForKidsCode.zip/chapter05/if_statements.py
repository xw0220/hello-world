age = 25
if age > 20:
    print('You are too old!')
    print('Why are you here?')
    print('Why aren\'t you mowing a lawn or sorting papers?')
    
print("Want to hear a dirty joke?") 
age = 12
if age == 12:
    print("A pig fell in the mud!")
else:
    print("Shh. It's a secret.")
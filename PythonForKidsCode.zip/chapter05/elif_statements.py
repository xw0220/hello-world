age = 12
if age == 10:
    print("What do you call an unhappy cranberry?")
    print("A blueberry!")
elif age == 11:
    print("What did the green grape say to the blue grape?")
    print("Breathe! Breathe!")
elif age == 12:
    print("What did 0 say to 8?")
    print("Hi guys!")
elif age == 13:
    print("Why wasn't 10 afraid of 7?")
    print("Because rather than eating 9, 7 8 pi.")
else:
    print("Huh?")
age = 10
if age == 10:
    print("What's the best way to speak to a monster?")
    print("From as far away as possible!")
    
age = '10'
if age == '10':
    print("What's the best way to speak to a monster?")
    print("From as far away as possible!")
    
age = '10'
converted_age = int(age)
if converted_age == 10:
    print("What's the best way to speak to a monster?")
    print("From as far away as possible!")
hugehairypants = [ 'huge', 'hairy', 'pants' ]
for i in hugehairypants:
    print(i)
    for j in hugehairypants:
        print(j)
for x in range(0, 5):
    print('hello')
    
for x in range(0, 5):
    print('hello %s' % x)
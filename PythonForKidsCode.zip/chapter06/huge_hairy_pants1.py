hugehairypants = [ 'huge', 'hairy', 'pants' ]
for i in hugehairypants:
    print(i)
    print(i)
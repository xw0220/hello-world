public class HelloWorld {
	public static final void main(String[] args) {
		System.out.println("Hello World");
	}
}

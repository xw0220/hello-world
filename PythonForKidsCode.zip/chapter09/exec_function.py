my_small_program = '''print('ham')
print('sandwich')'''

exec(my_small_program)
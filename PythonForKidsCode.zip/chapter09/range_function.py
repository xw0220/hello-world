for x in range(0, 5):
    print(x)
    
print(list(range(0, 5)))

count_by_twos = list(range(0, 30, 2))
print(count_by_twos)
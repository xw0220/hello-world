#
# Place a file called test.txt in the same directory as you place this program... 
#

f = open('test.txt')
s = f.read()
print(s)
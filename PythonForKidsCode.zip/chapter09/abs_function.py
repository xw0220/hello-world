print(abs(10))
print(abs(-10))

steps = -3
if abs(steps) > 0:
    print('Character is moving')